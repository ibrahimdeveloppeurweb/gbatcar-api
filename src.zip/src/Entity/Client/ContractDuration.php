<?php

namespace App\Entity\Client;

use App\Repository\Client\ContractDurationRepository;
use App\Traits\SearchableTrait;
use App\Traits\UserObjectNoCodeTrait;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Gedmo\SoftDeleteable\Traits\SoftDeleteableEntity;
use Ramsey\Uuid\Uuid;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=ContractDurationRepository::class)
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false, hardDelete=true)
 */
class ContractDuration
{
    use SearchableTrait;
    use SoftDeleteableEntity;
    use UserObjectNoCodeTrait;

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"duration", "contract", "client"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"duration", "contract", "client"})
     */
    private $name;

    /**
     * @ORM\Column(type="integer")
     * @Groups({"duration", "contract", "client"})
     */
    private $monthsCount;

    public function __construct()
    {
        $this->uuid = Uuid::uuid4();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getMonthsCount(): ?int
    {
        return $this->monthsCount;
    }

    public function setMonthsCount(int $monthsCount): self
    {
        $this->monthsCount = $monthsCount;

        return $this;
    }

    public function getTitle(): string
    {
        return $this->name ?? '';
    }

    public function getDetail(): string
    {
        return 'Durée de contrat';
    }
}